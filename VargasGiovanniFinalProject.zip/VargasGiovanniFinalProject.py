import tkinter as tk
import random

class MoveCanvas(tk.Canvas):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
 
        self.dx = 0
        self.dy = 0
        self.user_x = 200
        self.user_y = 220
        self.user = self.create_rectangle(self.user_x, self.user_y, self.user_x + 10, self.user_y + 10, fill="blue")  # Create user rectangle
        
        self.dt = 25
        self.elapsed_time= 0 #Variable to track a elapsed time
        self.game_over_flag = False
        self.timer_label = tk.Label(self, text="Time: {:.1f}s".format(self.elapsed_time), font=("Helvetica", 12), fg="purple", bg="black")
        self.timer_label.pack(side="top", padx=10, pady=10)  # Add the timer label to the canvas
        self.tick()
      
    def tick(self):
        if not self.game_over_flag:
            self.move(self.user, self.dx, self.dy)  # Move the user rectangle
            
            self.elapsed_time += self.dt / 1000
            self.timer_label.config(text="Time: {:.1f}s".format(self.elapsed_time))
            
            # Drop a pixel from the top randomly
            drop_probability = 1 + self.dt // 100 #increase pixel drop over time 
            if random.randint(1, 20 * drop_probability) == 1:
                pixel_x = random.randint(0, self.winfo_width())
                pixel_y = 0
                pixel_size = 6 #settting the size of the falling pixels
                self.create_rectangle(pixel_x, pixel_y, pixel_x + pixel_size, pixel_y + pixel_size, fill="red", tags="pixel")
            
            # Move all pixels down with increasing speed
            for pixel in self.find_withtag("pixel"):
                speed = 4 + self.dt // 100 #increase speed over time
                self.move(pixel, 0, speed)
                pixel_coords = self.coords(pixel)
                if self.check_collision(pixel_coords):
                    # If a pixel hits the user's rectangle, game over
                    self.game_over()
        
        self.after(self.dt, self.tick)
 
    def change_heading(self, dx, dy):
        self.dx = dx
        self.dy = dy

    def check_collision(self, pixel_coords):
        user_coords = self.coords(self.user)
        if (user_coords[0] < pixel_coords[2] and user_coords[2] > pixel_coords[0] and
            user_coords[1] < pixel_coords[3] and user_coords[3] > pixel_coords[1]):
            return True
        return False

    def game_over(self):
        self.game_over_flag = True
        self.delete(tk.ALL)
        self.create_text(self.winfo_width() / 2, self.winfo_height() / 2, text="Game Over", font=("Helvetica", 24), fill="red")
        
          # Create the restart button after the game is over
        self.restart_button = tk.Button(self, text="Restart", command=self.restart_game, bg="black", fg="gold", font=("Helvetica", 12))
        self.restart_button.pack(side="bottom", padx=10, pady=10)  # Add the restart button to the canvas

    def restart_game(self):
        self.destroy()  # Close the current canvas
        create_game_window()   # Open a new game window

def create_game_window():
    game_window = tk.Toplevel()
    game_window.geometry("400x240")
    game_window.title("PnZ")
    
    canvas = MoveCanvas(game_window, bg="black")
    canvas.pack(fill="both", expand=True)
    
    ds = 5
    game_window.bind("<KeyPress-Left>", lambda event: canvas.change_heading(-ds, 0))
    game_window.bind("<KeyPress-Right>", lambda event: canvas.change_heading(ds, 0))
    game_window.bind("<KeyPress-Up>", lambda event: canvas.change_heading(0, -ds))
    game_window.bind("<KeyPress-Down>", lambda event: canvas.change_heading(0, ds))

def start_game():
    main_window.iconify()  # Hide the main window
    create_game_window()

main_window = tk.Tk()
main_window.geometry("400x240")
main_window.title("PnZ")
main_window.config(bg="black")

#Create and center the label
label_frame = tk.Frame(main_window, bg="black")
label_frame.pack(expand=True)
tk.Label(main_window, text="PnZ", bg="black", fg="red", font=("Helvetica", 18)).pack(pady=20)

#Create and center the start button
button_frame=tk.Frame(main_window, bg="black")
button_frame.pack(expand=True)
tk.Button(main_window, text="START", command=start_game, bg="black", fg="white", font=("Helvetica", 12)).pack(pady=10)

main_window.mainloop()